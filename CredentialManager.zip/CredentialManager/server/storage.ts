import { users, credentials, type User, type InsertUser, type Credential, type InsertCredential } from "@shared/schema";
import { db } from "./db";
import { eq, or, and, ilike } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createCredential(credential: InsertCredential & { userId: number }): Promise<Credential>;
  updateCredential(id: number, userId: number, credential: Partial<InsertCredential>): Promise<Credential>;
  deleteCredential(id: number, userId: number): Promise<void>;
  checkDuplicateCredential(userId: number, platform: string, username: string, accountName?: string, url?: string, accountIdentity?: string): Promise<boolean>;
  searchCredentials(userId: number, search: string): Promise<Credential[]>;
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async checkDuplicateCredential(userId: number, credential: InsertCredential): Promise<boolean> {
    const [existing] = await db
      .select()
      .from(credentials)
      .where(
        and(
          eq(credentials.userId, userId),
          eq(credentials.platform, credential.platform),
          eq(credentials.username, credential.username),
          eq(credentials.password, credential.password),
          eq(credentials.accountIdentity, credential.accountIdentity),
          eq(credentials.accountType, credential.accountType),
          eq(credentials.status, credential.status),
          credential.accountName ? eq(credentials.accountName, credential.accountName) : undefined,
          credential.url ? eq(credentials.url, credential.url) : undefined,
          credential.specialPin ? eq(credentials.specialPin, credential.specialPin) : undefined,
          credential.recoveryNumber ? eq(credentials.recoveryNumber, credential.recoveryNumber) : undefined,
          credential.recoveryEmail ? eq(credentials.recoveryEmail, credential.recoveryEmail) : undefined
        )
      );
    
    return !!existing;
  }

  async createCredential(credential: InsertCredential & { userId: number }): Promise<Credential> {
    const [created] = await db.insert(credentials).values(credential).returning();
    return created;
  }

  async updateCredential(id: number, userId: number, credential: Partial<InsertCredential>): Promise<Credential> {
    const [updated] = await db
      .update(credentials)
      .set({ ...credential, lastChanged: new Date() })
      .where(and(eq(credentials.id, id), eq(credentials.userId, userId)))
      .returning();

    if (!updated) {
      throw new Error("Credential not found or you don't have permission to update it");
    }

    return updated;
  }

  async deleteCredential(id: number, userId: number): Promise<void> {
    const [deleted] = await db
      .delete(credentials)
      .where(and(eq(credentials.id, id), eq(credentials.userId, userId)))
      .returning();

    if (!deleted) {
      throw new Error("Credential not found or you don't have permission to delete it");
    }
  }

  async searchCredentials(userId: number, search: string): Promise<Credential[]> {
    // If no search term, return all credentials for the user
    if (!search) {
      return db
        .select()
        .from(credentials)
        .where(eq(credentials.userId, userId));
    }

    // Case-insensitive search across all relevant fields
    return db
      .select()
      .from(credentials)
      .where(
        and(
          eq(credentials.userId, userId),
          or(
            ilike(credentials.platform, `%${search}%`),
            ilike(credentials.accountName || '', `%${search}%`),
            ilike(credentials.username, `%${search}%`),
            ilike(credentials.accountIdentity, `%${search}%`),
            ilike(credentials.accountType, `%${search}%`),
            ilike(credentials.url || '', `%${search}%`),
            ilike(credentials.status, `%${search}%`),
            ilike(credentials.recoveryEmail || '', `%${search}%`)
          )
        )
      );
  }
}

export const storage = new DatabaseStorage();